package com.example.Proyectito;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectitoApplicationTests {

	@Test
	void contextLoads() {
	}

}
